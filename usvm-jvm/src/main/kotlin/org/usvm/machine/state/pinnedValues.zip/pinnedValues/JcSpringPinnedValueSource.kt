﻿package org.usvm.machine.state.pinnedValues

enum class JcSpringPinnedValueSource {
    REQUEST_HEADER,
    REQUEST_PARAM,
    REQUEST_PATH,
    REQUEST_MATRIX,
    REQUEST_BODY,
    REQUEST_HAS_BODY,
    REQUEST_USER
}