﻿package org.usvm.machine.state.pinnedValues

import org.jacodb.api.jvm.JcType
import org.usvm.UExpr
import org.usvm.USort

class JcSpringPinnedValue (
    val value: UExpr<USort>,
    val type: JcType,
){
    fun getValue(): UExpr<USort> {
        return value
    }
    
    fun getType(): JcType {
        return type
    }
}