﻿package org.usvm.machine.state.pinnedValues

import io.ksmt.utils.asExpr
import org.jacodb.api.jvm.JcType
import org.usvm.USort
import org.usvm.api.makeNullableSymbolicRef
import org.usvm.api.makeSymbolicRef
import org.usvm.machine.interpreter.JcStepScope

class JcSpringPinnedValues (
    private var pinnedValues: Map<JcSpringPinnedValueKey, JcSpringPinnedValue>
){
    fun getValue(key: JcSpringPinnedValueKey): JcSpringPinnedValue? {
        return pinnedValues.get(key)
    }

    fun setValue(key: JcSpringPinnedValueKey, value: JcSpringPinnedValue) {
        pinnedValues += key to value
    }
    
    fun createAndSetValue(key: JcSpringPinnedValueKey, type: JcType, scope: JcStepScope, sort: USort, nullable: Boolean = true): JcSpringPinnedValue {
        val newValueExpr = 
            if (nullable) scope.makeNullableSymbolicRef(type)?.asExpr(sort)
            else scope.makeSymbolicRef(type)?.asExpr(sort)
        val newValue = JcSpringPinnedValue(newValueExpr!!, type)
        setValue(key, newValue)
        return newValue
    }
}